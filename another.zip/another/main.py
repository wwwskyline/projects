import asyncio
from aiogram import Dispatcher, Bot, types

dp = Dispatcher()

@dp.message()
async def hello(message: types.Message):
    await message.send_copy(message.from_user.id)

async def main():
    token = "ENTER YOUR TOKEN HERE"
    bot = Bot(token=token)
    await dp.start_polling(bot)

if __name__ == "__main__":
    try:
        asyncio.run(main())
        print('Bot working')
    except KeyboardInterrupt:
        print('Bot is not working')